import java.util.Scanner;
public class ArrayFromInput {
    public static void main(String[] args) {
       Scanner scnr = new Scanner(System.in);



       String[] fruitName = new String[4];
       String[] fruitColor = new String[4];
       int[] numFruit = new int[4];

       for(int i = 0; i < 4; i++) {
           System.out.println("Enter name of fruit: ");
           fruitName[i] = scnr.nextLine();
           System.out.println("Enter color of fruit: ");
           fruitColor[i] = scnr.nextLine();
           System.out.println("Enter number of fruits");
           numFruit[i] = Integer.parseInt(scnr.nextLine());
       }
       System.out.println("Fruit:              Fruit Color:              Fruit Count:");
       for (int j = 0; j < fruitName.length; j++) {
           System.out.println(fruitName[j] + "                 " + fruitColor[j] + "                 " + numFruit[j]);
       }


    }
}
