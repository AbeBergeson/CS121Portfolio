import java.util.Scanner;
import java.util.Arrays;
public class CopyArrayNew {
    public static void main(String[] args) {
    Scanner scnr = new Scanner(System.in);

    System.out.print("Enter number of array elements: ");
    int number = Integer.parseInt(scnr.nextLine());
    int c = number-1;
    int [] array1 = new int[number];
    int [] array2 = new int[number];
    int [] array3 = new int[number];
    int [] array4 = new int[number];

    for (int i = 0; i < number; i++) {
        System.out.println("Enter array element " + i + ":");
        int element = scnr.nextInt();
        array1[i] = element;
    }

    for (int j = 0; j<number; j++) {
        array3[j] = array1[j] * array1[j];
    }

    for (int i = 0; i < number; i++) {
        array4[i]=array1[c];
        c--;
    }




    System.out.println("Array 1 ");
    System.out.println(Arrays.toString(array1));
    array2 = array1;
    System.out.println("Array 2 - copy ");
    System.out.println(Arrays.toString(array2));
    System.out.println("Array 3 - squared ");
    System.out.println(Arrays.toString(array3));
    System.out.println("Array 4 - reversed ");
    System.out.println(Arrays.toString(array4));

    }
}
