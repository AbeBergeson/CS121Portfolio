import java.util.Scanner;
public class CopyArray {
    public static void main(String[] args) {
        Scanner scnr = new Scanner(System.in);

        System.out.println("Enter in number of student names: ");
        //int numOfStudents = Integer.parseInt(scnr.nextLine());
        //System.out.println("The user input: " + numOfStudents);
        //numOfStudents = 5;
        //System.out.println("The changed input: " + numOfStudents);
        final int NUM_OF_STUDENTS = Integer.parseInt(scnr.nextLine());
        System.out.println("The user input: " + NUM_OF_STUDENTS);
        String [] studentNames = new String [NUM_OF_STUDENTS];


        for (int i = 0; i<studentNames.length; i++) {
            System.out.println("Enter in student %d :");
            String name = scnr.nextLine();
            studentNames[i] = scnr.nextLine();
        }
        for (int i = 0; i<studentNames.length; i++) {
            System.out.println(studentNames[i]);
        }
    }
}
