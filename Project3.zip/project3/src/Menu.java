import java.util.Scanner;

public class Menu {

    private Scanner scnr = new Scanner(System.in);
    private Bank bank = new Bank();

    public void displayMenu() {
        while (true) {
            String selection;
            System.out.println("\n* * * * * * * * MENU * * * * * * * *\n");
            System.out.print("Please make a selection:\n" +
                    "1) Access Account\n" +
                    "2) Open a New Account\n" +
                    "3) Close all Accounts\n" +
                    "4) Exit\n" +
                    ">>");

            selection = scnr.nextLine();   // Get information from user
            // If-else-if  statements to
            if (selection.equals("1")) {
                accessAccount();
            } else if (selection.equals("2")) {
                //deleteStudent();
            } else if (selection.equals("3")) {
                //displayStudent();
            } else if (selection.equals("4")) {
                System.out.println("Exiting...");
                break;
            } else {
                System.out.println("Invalid entry");

            }
        }
    }

    private void accessAccount() {
        System.out.println("Enter your individual PIN Number: ");
        int pin = Integer.parseInt(scnr.nextLine());
        Customer userInput = bank.getCustomer(pin);
        if (userInput == null) {
            System.out.println("PIN is not valid.");
            return;
        } else {
            System.out.println("PIN identified. Accounts:" +
                    " " + userInput.getAllAccounts());

        }
    }

}
