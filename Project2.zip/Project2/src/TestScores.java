import java.util.Scanner;
import java.util.Random;
public class TestScores {
    public static void main(String[] args) {
        Scanner scnr = new Scanner(System.in);
        Random rand = new Random();

        final int SIZE = rand.nextInt(10 - 3 + 1) + 3;
        //System.out.println(SIZE);

        int[] testScores = new int[SIZE];
        char[] letterGrade = new char[SIZE];

        System.out.println("Enter your " + SIZE + " test scores:");

        for (int i = 0; i < SIZE; i++) {
            System.out.print("Enter test " + (i + 1) + " score: ");
            testScores[i] = scnr.nextInt();
        }

        for (int i = 0; i < SIZE; i++) {
            letterGrade[i] = getLetterGrade(testScores[i]);

        }

        printGrades(testScores, letterGrade);

        printHighestScore(testScores);

        printLowestScore(testScores);

        printAverageScore(testScores);
    }

    public static char getLetterGrade(int testScore) {
        if (testScore >= 90 && testScore <= 100)
            return 'A';
        else if (testScore >= 80 && testScore <= 89)
            return 'B';
        else if (testScore >= 70 && testScore <= 79)
            return 'C';
        else if (testScore >= 60 && testScore <= 69)
            return 'D';
        else
            return 'F';
    }


    public static void printGrades(int[] testScores, char[] letterGrade) {
        System.out.println("--------------------");
        System.out.println("Score       Grade");
        for (int i = 0; i < testScores.length; i++) {
            System.out.print(testScores[i] + "           " + letterGrade[i] + "\n");
        }
        System.out.println("--------------------");
    }
    public static void printHighestScore(int[] testScores) {
        int highest = 0;
        for(int i = 0; i < testScores.length; i++) {
            if (testScores[i] > highest) {
                highest = testScores[i];

            }
        }
        System.out.println("The highest score is: " + highest);
    }

    public static void printLowestScore(int[] testScores) {
        int lowest = 100;
        for(int i = 0; i < testScores.length; i++) {
            if (testScores[i] < lowest) {
                lowest = testScores[i];

            }
        }
        System.out.println("The lowest score is: " + lowest);
    }

    public static void printAverageScore(int[] testScores) {
    double average = 0;
    int sum = 0;
    for(int i = 0; i < testScores.length; i++) {
        sum = sum + testScores[i];
    }
    average = (double)sum / testScores.length;
        System.out.println("Average score is: " + average);
        System.out.print("-------------------");
    }


}